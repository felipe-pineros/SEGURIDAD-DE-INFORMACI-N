
IFACE="enp0s3"
IP_BLOQUEADA="10.0.2.15"
IP_JOSEDOMINGO="127.0.0.53#53"
IP_CLIENTE_MYSQL="10.0.2.15"


RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[+]${NC} $*"; }
warn()  { echo -e "${YELLOW}[!]${NC} $*"; }
error() { echo -e "${RED}[-]${NC} $*"; }

[[ $EUID -ne 0 ]] && { error "Ejecuta como root (sudo)."; exit 1; }

limpiar() {
    info "Limpiando reglas..."
    iptables -F; iptables -X; iptables -Z
    iptables -t nat -F; iptables -t mangle -F
}

iniciar() {
    limpiar

    # 1. Política por defecto DROP
    info "Política DROP en INPUT, OUTPUT, FORWARD..."
    iptables -P INPUT   DROP
    iptables -P FORWARD DROP
    iptables -P OUTPUT  DROP

    # 2. Loopback
    info "Loopback..."
    iptables -A INPUT  -i lo -j ACCEPT
    iptables -A OUTPUT -o lo -j ACCEPT

    # 3. Conexiones establecidas / relacionadas
    info "ESTABLISHED/RELATED..."
    iptables -A INPUT  -m state --state ESTABLISHED,RELATED -j ACCEPT
    iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    iptables -A INPUT  -m state --state INVALID -j DROP
    iptables -A OUTPUT -m state --state INVALID -j DROP

    # 4. SSH
    info "SSH (22)..."
    iptables -A INPUT  -p tcp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
    iptables -A OUTPUT -p tcp --sport 22 -m state --state ESTABLISHED     -j ACCEPT

    # 5. ICMP
    info "ICMP ping/pong..."
    iptables -A INPUT  -p icmp --icmp-type echo-request -j ACCEPT
    iptables -A OUTPUT -p icmp --icmp-type echo-reply   -j ACCEPT
    iptables -A OUTPUT -p icmp --icmp-type echo-request -j ACCEPT
    iptables -A INPUT  -p icmp --icmp-type echo-reply   -j ACCEPT

    # 6. DNS
    info "DNS (53 UDP/TCP)..."
    iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
    iptables -A INPUT  -p udp --sport 53 -j ACCEPT
    iptables -A OUTPUT -p tcp --dport 53 -j ACCEPT
    iptables -A INPUT  -p tcp --sport 53 -j ACCEPT

    # 7. HTTP/HTTPS con multiport
    info "HTTP/HTTPS multiport (80,443)..."
    iptables -A OUTPUT -p tcp -m multiport --dports 80,443 -j ACCEPT
    iptables -A INPUT  -p tcp -m multiport --dports 80,443 -j ACCEPT

    # 8. Bloquear IP concreta al servidor web
    warn "Bloqueando ${IP_BLOQUEADA} -> web..."
    iptables -A INPUT -p tcp -m multiport --dports 80,443 \
             -s "${IP_BLOQUEADA}" -j DROP

    # 9. Bloquear josedomingo.org
    warn "Bloqueando josedomingo.org (${IP_JOSEDOMINGO})..."
    iptables -A INPUT  -p tcp -m multiport --dports 80,443 -s "${IP_JOSEDOMINGO}" -j DROP
    iptables -A OUTPUT -p tcp -m multiport --dports 80,443 -d "${IP_JOSEDOMINGO}" -j DROP

    # 10. MySQL solo desde cliente autorizado
    info "MySQL solo para ${IP_CLIENTE_MYSQL}..."
    iptables -A INPUT -p tcp --dport 3306 ! -s "${IP_CLIENTE_MYSQL}" -j DROP
    iptables -A INPUT  -p tcp --dport 3306 -s "${IP_CLIENTE_MYSQL}" \
             -m state --state NEW,ESTABLISHED -j ACCEPT
    iptables -A OUTPUT -p tcp --sport 3306 -d "${IP_CLIENTE_MYSQL}" \
             -m state --state ESTABLISHED -j ACCEPT

    info "=== Firewall activo ==="
}

detener() {
    warn "Deteniendo firewall (política ACCEPT)..."
    limpiar
    iptables -P INPUT ACCEPT; iptables -P FORWARD ACCEPT; iptables -P OUTPUT ACCEPT
    info "Firewall detenido."
}

estado() {
    echo ""; echo "=== INPUT ==="; iptables -L INPUT -v -n --line-numbers
    echo ""; echo "=== OUTPUT ==="; iptables -L OUTPUT -v -n --line-numbers
    echo ""; echo "=== FORWARD ==="; iptables -L FORWARD -v -n --line-numbers
}

persistir() {
    if command -v netfilter-persistent &>/dev/null; then
        netfilter-persistent save
    else
        mkdir -p /etc/iptables && iptables-save > /etc/iptables/rules.v4
        info "Guardado en /etc/iptables/rules.v4"
    fi
}

case "$1" in
    start|iniciar)   iniciar   ;;
    stop|detener)    detener   ;;
    restart)         detener; sleep 1; iniciar ;;
    status|estado)   estado    ;;
    save|guardar)    persistir ;;
    *) echo "Uso: sudo $0 {start|stop|restart|status|save}"; exit 1 ;;
esac
exit 0
